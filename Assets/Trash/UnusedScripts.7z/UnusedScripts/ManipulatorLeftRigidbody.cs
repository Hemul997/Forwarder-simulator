﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManipulatorLeftRigidbody : MonoBehaviour
{
    public int speed;
    public Rigidbody rb;
    private float X, Y, Z;
    public Vector3 eulerAngleVelocity = new Vector3(0f, 0f, 1000f);

    // Use this for initialization
    void Start()
    {
        rb.GetComponent<Rigidbody>();
    }

    void FixedUpdate()
    {
        if (Input.GetKey(KeyCode.Z))
        {
            Quaternion deltaRotation = Quaternion.Euler(eulerAngleVelocity * Time.deltaTime);
            //Quaternion deltaRotation = Quaternion.Euler(X, Y, Z);
            //rb.rotation = deltaRotation;
            rb.MoveRotation(rb.rotation * deltaRotation);
        }
        if (Input.GetKey(KeyCode.X))
        {
            Quaternion deltaRotation = Quaternion.Euler(-eulerAngleVelocity * Time.deltaTime);
            //Quaternion deltaRotation = Quaternion.Euler(X, Y, Z);
            //rb.rotation = deltaRotation;
            rb.MoveRotation(rb.rotation * deltaRotation);
        }


    }
}
