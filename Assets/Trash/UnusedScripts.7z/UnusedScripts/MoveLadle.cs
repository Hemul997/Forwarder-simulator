﻿using UnityEngine; 
using System.Collections;

public class MoveLadle: MonoBehaviour {

	private float X,Y,Z; 
	public int speeds; 
	// Use this for initialization 
	void Start () { 

	} 

	// Update is called once per frame 
	void Update () {
		float rotation = Input.GetAxis ("Ladle");
		//		if (Input.GetKey (KeyCode.L)) 
		Y += rotation * speeds * Time.deltaTime; 
		Y = Mathf.Clamp (Y, -50, 50);
		//if(Input.GetKey(KeyCode.Joystick1Button0)){
			 
		//	X+=speeds*Time.deltaTime;

		//	X = Mathf.Clamp (X, -30, 30);


		//	transform.localRotation = Quaternion.Euler (X, 0, 0);
		//}
	//	if(Input.GetKey(KeyCode.Joystick2Button0)){
	//		X-=speeds*Time.deltaTime;
	//		X = Mathf.Clamp (X, -30, 30);
	//		transform.localRotation = Quaternion.Euler (30-X, 0, 0);
	//	}

		transform.localRotation = Quaternion.Euler (X, Y, Z);

	} 
}