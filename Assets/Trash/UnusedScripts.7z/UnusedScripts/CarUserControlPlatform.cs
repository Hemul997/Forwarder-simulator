﻿using System;
using UnityEngine;

//namespace UnityStandardAssets.Vehicles.Car
//{
[RequireComponent(typeof (CarController))]
public class CarUserControlPlatform : MonoBehaviour
{
	private CarController m_Car; // the car controller we want to use


	private void Awake()
	{
		// get the car controller
		m_Car = GetComponent<CarController>();
	}


	private void FixedUpdate()
	{
		// pass the input to the car!
		float h1 = Input.GetAxis("Horizontal");
		float v1 = Input.GetAxis("Vertical");
		//#if !MOBILE_INPUT
					float handbrake = Input.GetAxis("Jump");
		//            m_Car.Move(h, v, v, handbrake);
		//#else
		m_Car.Move(0, 0, 0, handbrake);
		//#endif
	}
}
//}
