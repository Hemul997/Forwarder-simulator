﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PistonKinematic : MonoBehaviour {
	public float speed;
	public Rigidbody rb;
	private float force = 0;
	// Use this for initialization
	void Start () {

		rb = GetComponent<Rigidbody> ();
	}

	// Update is called once per frame
	void Update () {
		//if (Input.GetKey (KeyCode.UpArrow))
		//	rb.AddForceAtPosition (transform.up* Time.deltaTime*speed,transform.localPosition);
		float rotation = Input.GetAxis ("VerticalJoystick")*speed;
		rb.AddForce (transform.up*rotation, ForceMode.Force);
		//	force+=Time.deltaTime*speed;
		//if (Input.GetKey (KeyCode.DownArrow))
		//	rb.AddForce (transform.up*-speed, ForceMode.Force);
		//	force-=Time.deltaTime*speed;
		//rb.AddForce (transform.up* force,ForceMode.Force);
	}
}
