﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ignorecol2 : MonoBehaviour {

    public GameObject qqq;
    public GameObject col1;
  //  public GameObject col2;
    // Use this for initialization
    void Start()
    {
        Transform www = qqq.transform;
        //Transform eee = Instantiate (www) as Transform;
        Physics.IgnoreCollision(www.GetComponent<Collider>(), col1.GetComponent<Collider>());
    //    Physics.IgnoreCollision(www.GetComponent<Collider>(), col2.GetComponent<Collider>());
    }
    // Update is called once per frame
    void Update () {
		
	}
}
