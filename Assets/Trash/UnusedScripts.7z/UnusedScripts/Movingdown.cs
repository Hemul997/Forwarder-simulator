﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movingdown : MonoBehaviour {
	public GameObject Arrow2;
	public int speed1;
	private float X,Y,Z; 
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
//	void Update () {
//		float rotation1 = Input.GetAxis("DownArrow")*speed1;
//		Y += rotation1 * Time.deltaTime; 
//		transform.localRotation = Quaternion.Euler (Y,X, Z);
//	}
//}
//private float X,Y,Z; 
public int speeds; 
// Use this for initialization 
//void Start () { 

//} 

// Update is called once per frame 
void Update () {
		float rotation = Input.GetAxis ("DownArrow");
		//		if (Input.GetKey (KeyCode.L)) 
		Y += rotation * speeds * Time.deltaTime; 
		Y = Mathf.Clamp (Y, -30, 45);
		//		if (Input.GetKey (KeyCode.J)) 
		//			X -= rotation  * speeds * Time.deltaTime; 

		transform.localRotation = Quaternion.Euler (Y, X, Z);
	}
}