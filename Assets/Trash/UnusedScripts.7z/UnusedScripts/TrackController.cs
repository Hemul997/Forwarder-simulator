﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrackController : MonoBehaviour {

		public GameObject wheelCollider; //2

		public float wheelRadius = 0.15f; //3
		public float suspensionOffset = 0.05f; //4

		public float trackTextureSpeed = 2.5f; //5

		public GameObject leftTrack;  //6
		public Transform[] leftTrackUpperWheels; //7
		public Transform[] leftTrackWheels; //8
		public Transform[] leftTrackBones; //9

		public GameObject rightTrack; //6
		public Transform[] rightTrackUpperWheels; //7
		public Transform[] rightTrackWheels; //8
		public Transform[] rightTrackBones; //9

		public class WheelData { //10
			public Transform wheelTransform; //11
			public Transform boneTransform; //12
			public WheelCollider col; //13
			public Vector3 wheelStartPos; //14
			public Vector3 boneStartPos; //15
			public float rotation = 0.0f; //16
			public Quaternion startWheelAngle;	//17
		}

		protected WheelData[] leftTrackWheelData; //18
		protected WheelData[] rightTrackWheelData; //18

		protected float leftTrackTextureOffset = 0.0f; //19
		protected float rightTrackTextureOffset = 0.0f; //19
}