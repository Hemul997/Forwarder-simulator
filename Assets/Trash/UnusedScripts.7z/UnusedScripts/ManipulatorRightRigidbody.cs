﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManipulatorRightRigidbody: MonoBehaviour
{
    public int speed;
    public Rigidbody rb;
    private float X, Y, Z;
    public Vector3 eulerAngleVelocity;
    // Use this for initialization
    void Start()
    {
        rb.GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //float rotation = Input.GetAxis ("ManipulatorOpen");
        if (Input.GetKey(KeyCode.Z))
        {
            //Z += speed * Time.deltaTime;
            //Z = Mathf.Clamp(Z, 0, 90);
            //Quaternion deltaRotation = Quaternion.Euler(X, Y, Z);
            Quaternion deltaRotation = Quaternion.Euler(eulerAngleVelocity * Time.deltaTime);
            //rb.rotation = deltaRotation;
            rb.MoveRotation(rb.rotation * deltaRotation);
        }
        if (Input.GetKey(KeyCode.X))
        {
            //Z -= speed * Time.deltaTime;
            //Z = Mathf.Clamp(Z, 0, 90);
            //Quaternion deltaRotation = Quaternion.Euler(X, Y, Z);
            Quaternion deltaRotation = Quaternion.Euler(-eulerAngleVelocity * Time.deltaTime);
            //rb.rotation = deltaRotation;
            rb.MoveRotation(rb.rotation * deltaRotation);
        }

    }
}
