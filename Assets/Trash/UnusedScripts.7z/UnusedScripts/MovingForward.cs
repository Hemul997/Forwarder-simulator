﻿using UnityEngine; 
using System.Collections;

public class MovingForward: MonoBehaviour {

	private float X,Y,Z; 
	public int speedmove; 
	public int speedrot;
	// Use this for initialization 
	void Start () { 

	} 

	// Update is called once per frame 
	void Update () {
		float rotation = Input.GetAxis ("HorizontalJoystick");
		if (Input.GetKey (KeyCode.UpArrow))
			transform.position -= transform.forward * speedmove * Time.deltaTime;
			X += 0.1f*speedmove * Time.deltaTime; 
				if (Input.GetKey (KeyCode.DownArrow)) 
			transform.position += transform.forward * speedmove * Time.deltaTime;
			X -= 0.1f*speedmove * Time.deltaTime; 
				if (Input.GetKey (KeyCode.RightArrow))
			Y += speedrot * Time.deltaTime; 
				if (Input.GetKey (KeyCode.LeftArrow))
			Y -= speedrot * Time.deltaTime; 
		transform.localRotation = Quaternion.Euler (0f, Y, 0f);
		//transform.Translate (X, 0f, 0f);
	//	transform.Position= 
			//(X, 0f, 0f);

	} 
}