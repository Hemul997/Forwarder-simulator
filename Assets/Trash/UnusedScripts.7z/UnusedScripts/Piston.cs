﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Piston : MonoBehaviour {
	public float speed;
	public Rigidbody rb;
	private float force = 0;
	private float thrust=0;
	private Vector3 v3;
	// Use this for initialization
	void Start () {
		
		rb = GetComponent<Rigidbody> ();
	}
	
	// Update is called once per frame
	void Update () {
		//if (Input.GetKey (KeyCode.UpArrow))
		//	rb.AddForceAtPosition (transform.up* Time.deltaTime*speed,transform.localPosition);
		float rotation = Input.GetAxis ("HorizontalJoystick");
		thrust += rotation*speed;
		v3=new Vector3(0f,thrust,0f);
		rb.AddForce (transform.up*speed, ForceMode.Force);
		//rb.AddTorque(transform
		//Vector3 direction = rb.transform.position - transform.position;
		//rb.AddForceAtPosition (direction.normalized, transform.position);
		//	(0f,thrust,0f));
		//	force+=Time.deltaTime*speed;
		//if (Input.GetKey (KeyCode.DownArrow))
		//	rb.AddForce (transform.up*-speed, ForceMode.Force);
		//	force-=Time.deltaTime*speed;
		//rb.AddForce (transform.up* force,ForceMode.Force);
	}
} 
