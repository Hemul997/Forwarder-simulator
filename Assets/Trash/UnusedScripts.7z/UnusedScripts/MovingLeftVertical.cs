﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingLeftVertical : MonoBehaviour {

//		public GameObject Arrow;
//		public int speed1;
//		private float X,Y,Z;
//		void Update () {
//			float rotation1 = Input.GetAxis("Vertical")*speed1;
//			rotation1*=Time.deltaTime;
//			transform.Rotate(rotation1,0,0);

//		float rotation = Input.GetAxis ("Horizontal") * speed1;
//		rotation*=Time.deltaTime;
//		transform.Rotate(-rotation,0,0);
//	}
//}

	 
//	void Start () { 

//	} 

	// Update is called once per frame 
//	void Update () {
//		float rotation1 = Input.GetAxis ("Vertical") * speed1;
//		Y += rotation1 * Time.deltaTime; 
//		transform.localRotation = Quaternion.Euler (Y,X, Z);
//		float rotation = Input.GetAxis ("Horizontal") * speed1;
//		rotation*=Time.deltaTime;
//		transform.Rotate(-rotation,0,0);
//	}

		private float X,Y,Z; 
		public int speeds; 
		// Use this for initialization 
		void Start () { 

		} 

		// Update is called once per frame 
		void Update () {
		float rotation = Input.GetAxis ("VerticalJoystick") * speeds;
//			if (Input.GetKey (KeyCode.I)) 
				Y += rotation * speeds * Time.deltaTime; 
		Y = Mathf.Clamp (Y, -45, 30);
//			if (Input.GetKey (KeyCode.K)) 
//				Y -= 1f  * speeds * Time.deltaTime;

			transform.localRotation = Quaternion.Euler (Y, X, Z);

		} 
	}