﻿//using UnityEngine;
//using System.Collections;

//public class MovingLeft : MonoBehaviour {

//	public GameObject platform;
//	public int speed;

//	void Update () {
//		float rotation = Input.GetAxis("Horizontal")*speed;
//		rotation*=Time.deltaTime;
//		transform.Rotate(0,rotation,0);
//	}

//		private float X,Y,Z; 
//		public int speed; 

//	void Update () {
//			float rotation = Input.GetAxis("Horizontal")*speed;
//			X += rotation * Time.deltaTime; 
//			transform.localRotation = Quaternion.Euler (Y,X, Z);
			
//		} 
//	}
	
using UnityEngine; 
using System.Collections;

public class MovingLeft: MonoBehaviour {

	private float X,Y,Z; 
	public int speeds; 
	// Use this for initialization 
	void Start () { 

	} 

	// Update is called once per frame 
	void Update () {
		float rotation = Input.GetAxis ("HorizontalJoystick");
//		if (Input.GetKey (KeyCode.L)) 
		if(rotation>=0.3f || rotation<=-0.3f){
			X += rotation * speeds * Time.deltaTime; 
		X = Mathf.Clamp (X, -100, 100);
//		if (Input.GetKey (KeyCode.J)) 
//			X -= rotation  * speeds * Time.deltaTime; 
		}
		transform.localRotation = Quaternion.Euler (Y, X, Z);

	} 
}