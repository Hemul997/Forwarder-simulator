﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ladle2 : MonoBehaviour {
	public int speed;
	public Rigidbody rb;
	private float X,Y,Z;
	// Use this for initialization
	void Start () {
		
	}
	
	void Update () {
		//rb.AddRelativeForce (-Z,0,0);
		if(Input.GetKey(KeyCode.Joystick1Button1)){
			//Z+=speed*Time.deltaTime;
			//Z = Mathf.Clamp (Z,-3.5f, -0.5f);

			rb.AddRelativeTorque (-speed,0,0);
			//Z-=speed;
			//transform.localPosition = new Vector3(Z, Y, X);
		}
		if(Input.GetKey(KeyCode.Joystick2Button1)){
			//Z-=speed*Time.deltaTime;
			//Z = Mathf.Clamp (Z,-3.5f, -0.5f);
			//transform.localPosition = new Vector3 (Z, Y, X);
			//Z-=speed;
			rb.AddRelativeTorque(speed,0,0);
		}

	} 
}