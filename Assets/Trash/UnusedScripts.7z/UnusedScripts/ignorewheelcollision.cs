﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ignorewheelcollision : MonoBehaviour {

    public GameObject wheel1;
    public GameObject wheel2;
    public GameObject wheel3;
    public GameObject wheel4;
    public GameObject wheel5;
    public GameObject wheel6;
    public GameObject wheel7;
    public GameObject wheel8;
    public GameObject cilinder;
    // Use this for initialization
    void Start()
    {
        
        Physics.IgnoreCollision(wheel1.GetComponent<Collider>(), cilinder.GetComponent<Collider>());
        Physics.IgnoreCollision(wheel2.GetComponent<Collider>(), cilinder.GetComponent<Collider>());
        Physics.IgnoreCollision(wheel3.GetComponent<Collider>(), cilinder.GetComponent<Collider>());
        Physics.IgnoreCollision(wheel4.GetComponent<Collider>(), cilinder.GetComponent<Collider>());
        Physics.IgnoreCollision(wheel5.GetComponent<Collider>(), cilinder.GetComponent<Collider>());
        Physics.IgnoreCollision(wheel6.GetComponent<Collider>(), cilinder.GetComponent<Collider>());
        Physics.IgnoreCollision(wheel7.GetComponent<Collider>(), cilinder.GetComponent<Collider>());
        Physics.IgnoreCollision(wheel8.GetComponent<Collider>(), cilinder.GetComponent<Collider>());
    }

    // Update is called once per frame
    void Update () {
		
	}
}
