﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class выдвиж : MonoBehaviour {
	private float X,Y,Z; 
	public Rigidbody rb;
	void Start () {
		}
	public int speeds; 
 
	void Update () {
		//float rotation = Input.GetAxis ("DownArrow");
				if (Input.GetKey (KeyCode.Joystick1Button0)) 
		Y +=  speeds * Time.deltaTime; 
				if (Input.GetKey (KeyCode.Joystick2Button0)) 
		Y -=  speeds * Time.deltaTime; 
		Y = Mathf.Clamp (Y, -4.4f, -0.2443595f);
		rb.transform.localPosition =new Vector3(X, Y, Z);
	}
}