﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManipLeft : MonoBehaviour {
	public int speed;
	public Rigidbody rb;
	private float X,Y,Z; 
	public GameObject Parent;
	public GameObject Child;
	public Rigidbody ChildRb;

	// Use this for initialization
	void Start () {
		
	}

//	void OnCollisionEnter(Collision col)
//	{
//		if (col.gameObject.GetComponent<Rigidbody> ()) {
//			if (col.gameObject.name == "Cylinder") {
//				if (Input.GetKey(KeyCode.Joystick1Button1)) {
//					Child.transform.SetParent (Parent.transform);
//					ChildRb.isKinematic = true;
//				}
//			}
//		}
//	}
		void Update () {
		//float rotation = Input.GetAxis ("ManipulatorOpen");
		if(Input.GetKey(KeyCode.Joystick1Button1)){
		Z-=speed*Time.deltaTime;
			//rb.AddRelativeTorque (0,0,speed);
		Z = Mathf.Clamp (Z, -90, 0);
		transform.localRotation = Quaternion.Euler (X, Y, Z);
		}
		if(Input.GetKey(KeyCode.Joystick2Button1)){
			Z+=speed*Time.deltaTime;
//			Child.transform.SetParent (Parent.transform,false);
//			ChildRb.isKinematic = false;
		//	rb.AddRelativeTorque (speed,0,0);
			Z = Mathf.Clamp (Z, -90, 0);
			transform.localRotation = Quaternion.Euler (X, Y,Z);
					}


	} 
}
	