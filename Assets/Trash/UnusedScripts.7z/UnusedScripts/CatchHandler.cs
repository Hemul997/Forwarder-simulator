﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CatchHandler : MonoBehaviour {
	private GameObject Parent;
	public GameObject Child;
    public GameObject LeftClaw;
    public GameObject RightClaw;

	private bool isJoint = false;

	// Use this for initialization
	void Start () {
		StartCoroutine (PutBal ());
	}
	void OnCollisionEnter(Collision collision)
	{
        if (collision.gameObject.name == LeftClaw.name || collision.gameObject.name == RightClaw.name)
        {
            if (collision.gameObject.name == RightClaw.name)
                Parent = RightClaw;
            else
                Parent = LeftClaw;
            if (!isJoint && Input.GetKey(KeyCode.Joystick1Button1))
            {
                Debug.Log("Catch");
                Child.transform.parent = Parent.transform;
                Child.AddComponent<FixedJoint>();
                Child.GetComponent<FixedJoint>().connectedBody = Parent.GetComponent<Rigidbody>();
                isJoint = true;
            }
        }

	//	if (col.gameObject.GetComponent<Rigidbody> ()) {
			//Debug.Log ("kek1" + col.gameObject.name);
			//if (col.gameObject.name == "manipulator") {
		//if (col.gameObject.name == Parent.gameObject.name) {
		//	Debug.Log ("kek");
		//	if (!isjoint) {
		//		Child.transform.parent = Parent.transform;
		//		Child.AddComponent<FixedJoint> ();
		//		Child.GetComponent <FixedJoint> ().connectedBody = Parent.GetComponent<Rigidbody> (); 
		//		isjoint = true;
		//		Child.GetComponent<Rigidbody> ().isKinematic = true;
		//	}
		//}
			//}
		//}
	}
	// Update is called once per frame
	IEnumerator PutBal () {
		while(true){
			if (Input.GetKey (KeyCode.Joystick2Button1)) {
				Destroy (Child.GetComponent<FixedJoint> ());
				isJoint = false;
				Child.GetComponent<Rigidbody> ().isKinematic = false;
				Child.transform.parent = null;
			}
			yield return new WaitForSeconds (1f);
		}
	}
}
